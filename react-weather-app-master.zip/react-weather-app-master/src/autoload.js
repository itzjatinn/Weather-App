//import the bootstrap library
import "bootstrap/dist/css/bootstrap.min.css";
import "bootstrap/dist/css/bootstrap.min.css.map";
import "bootstrap/dist/js/bootstrap.js";
import "bootstrap/dist/js/bootstrap.min.js.map";

//custom scripts
import "./inc/styles/style.css";
import "./inc/scripts/script.js";

//animation scripts
import "./inc/styles/three-dots.css";

//database scripts
